INDEX_NAME = "gayavectorindex"
