import os

from dotenv import load_dotenv

load_dotenv()


from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import ReadTheDocsLoader
#from langchain_openai import OpenAIEmbeddings
#from langchain.llm import AzureOpenAI
from langchain_openai import AzureOpenAIEmbeddings
from langchain_pinecone import PineconeVectorStore
from consts import INDEX_NAME

#embeddings = AzureOpenAIEmbeddings(model="text-embedding-3-small")
embeddings = AzureOpenAIEmbeddings(model="text-embedding-3-small")

def ingest_docs():
    try:
        loader = ReadTheDocsLoader("langchaindoc3",encoding='utf-8')
        raw_documents = loader.load()
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=600, chunk_overlap=50, separators=["\n\n", "\n", "\r\n", " ", ""])
        documents = text_splitter.split_documents(raw_documents)
        print("Split {} documents".format(len(documents)))
        for doc in documents:
            new_url = doc.metadata["source"]
            new_url = new_url.replace("langchain-docs", "https:/")
            doc.metadata.update({"source": new_url})

        print(f"Going to add {len(documents)} to Pinecone")
        PineconeVectorStore.from_documents(documents, embeddings, index_name="gayavectorindex")
        print("****Loading to vectorstore done ***")
    except UnicodeDecodeError as e:
        print(f"Error decoding data: {e}")
"""loader = ReadTheDocsLoader("langchaindocuments")
    raw_documents = loader.load()
    decoded_documents = [doc.decode('utf-8') for doc in raw_documents]
    print(f"loaded {len(decoded_documents)} documents")

    text_splitter = RecursiveCharacterTextSplitter(chunk_size=600, chunk_overlap=50)
    documents = text_splitter.split_documents(decoded_documents)
    for doc in documents:
        new_url = doc.metadata["source"]
        new_url = new_url.replace("langchain-docs", "https:/")
        doc.metadata.update({"source": new_url})

    print(f"Going to add {len(documents)} to Pinecone")
    PineconeVectorStore.from_documents(documents, embeddings, index_name="langchain-index")
    print("****Loading to vectorstore done ***")

"""
def ingest_docs2() -> None:
    from langchain_community.document_loaders import FireCrawlLoader

    langchain_documents_base_urls = [
        "https://python.langchain.com/v0.2/docs/integrations/chat/",
        "https://python.langchain.com/v0.2/docs/integrations/llms/",
        "https://python.langchain.com/v0.2/docs/integrations/text_embedding/",
        "https://python.langchain.com/v0.2/docs/integrations/document_loaders/",
        "https://python.langchain.com/v0.2/docs/integrations/document_transformers/",
        "https://python.langchain.com/v0.2/docs/integrations/vectorstores/",
        "https://python.langchain.com/v0.2/docs/integrations/retrievers/",
        "https://python.langchain.com/v0.2/docs/integrations/tools/",
        "https://python.langchain.com/v0.2/docs/integrations/stores/",
        "https://python.langchain.com/v0.2/docs/integrations/llm_caching/",
        "https://python.langchain.com/v0.2/docs/integrations/graphs/",
        "https://python.langchain.com/v0.2/docs/integrations/memory/",
        "https://python.langchain.com/v0.2/docs/integrations/callbacks/",
        "https://python.langchain.com/v0.2/docs/integrations/chat_loaders/",
        "https://python.langchain.com/v0.2/docs/concepts/",
    ]
 #   langchain_documents_base_urls2 = [langchain_documents_base_urls[0]]
    for url in langchain_documents_base_urls:
        print(f"FireCrawling {url=}")
        loader = FireCrawlLoader(
            url=url,
            mode="crawl",
            params={
                "crawlerOptions":{"limit": 5},
                "wait_until_done":True,
            },
        )
        docs = loader.load()

        print(f"Going to add {len(docs)} documents to Pinecone")
        PineconeVectorStore.from_documents(
            docs, embeddings, index_name="gayavectorindex"
        )
        print(f"****Loading {url}* to vectorstore done ***")


if __name__ == "__main__":
    ingest_docs()
