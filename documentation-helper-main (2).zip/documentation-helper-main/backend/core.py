import os
from tabnanny import verbose

from dotenv import load_dotenv
from langchain.chains.summarize.map_reduce_prompt import prompt_template
from openai import api_version, api_key

load_dotenv()
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
import langsmith

from typing import Any, Dict, List
from langchain_community.document_loaders import ReadTheDocsLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain import hub
from langchain_core.prompts import PromptTemplate,ChatPromptTemplate
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain.chains.history_aware_retriever import create_history_aware_retriever
from langchain.chains.retrieval import create_retrieval_chain
from langchain_openai import ChatOpenAI
from langchain_openai import AzureOpenAIEmbeddings,AzureChatOpenAI,AzureOpenAI,OpenAIEmbeddings
from langchain_pinecone import PineconeVectorStore
from langchain.chains import RetrievalQA, ConversationalRetrievalChain
import pydantic
from consts import INDEX_NAME
from openai import AzureOpenAI

def run_llm(query: str):
    embeddings = AzureOpenAIEmbeddings(model="text-embedding-3-small")
    docsearch = PineconeVectorStore(index_name=INDEX_NAME, embedding=embeddings)
    ##chat=AzureChatOpenAI(verbose=True, temperature=0,api_version='2023-03-15')
    chat = AzureChatOpenAI(verbose=True, temperature=0, api_version="2024-05-01-preview",
                           openai_api_key=os.getenv("AZURE_OPENAI_API_KEY"),
                           azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
                           deployment_name='gpt-35-turbo',
                           api_key=os.getenv("AZURE_OPENAI_API_KEY")
                           )
    rephrase_prompt = hub.pull("langchain-ai/chat-langchain-rephrase")
  #  model_id="azureml://registries/azure-openai/models/gpt-35-turbo/versions/0125"
    retrieval_qa_chat_prompt = hub.pull("langchain-ai/retrieval-qa-chat")
    stuff_documents_chain = create_stuff_documents_chain(chat,retrieval_qa_chat_prompt)

 #   history_aware_retriever = create_history_aware_retriever(
 #       llm=chat, retriever=docseaazureml://registries/azure-openai/models/gpt-35-turbo/versions/0125rch.as_retriever(), prompt=rephrase_prompt
 #   )
    qa = create_retrieval_chain(
           retriever=docsearch.as_retriever(), combine_docs_chain=stuff_documents_chain
         )

    result = qa.invoke(input={"input": query})
    return result


def format_docs(docs):
    return "\n\n".join(doc.page_content for doc in docs)


def run_llm2(query: str):
    embeddings = AzureOpenAIEmbeddings()
    docsearch = PineconeVectorStore(index_name=INDEX_NAME, embedding=embeddings)
    chat = AzureChatOpenAI(verbose=True, temperature=0, api_version="2024-05-01-preview",
                           openai_api_key=os.getenv("AZURE_OPENAI_API_KEY"),
                           azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
                           deployment_name='gpt-35-turbo',
                           api_key=os.getenv("AZURE_OPENAI_API_KEY")
                           )

    retrieval_qa_chat_prompt = hub.pull("langchain-ai/retrieval-qa-chat")

    rag_chain = (
        {
            "context": docsearch.as_retriever() | format_docs,
            "input": RunnablePassthrough(),
        }
        | retrieval_qa_chat_prompt
        | chat
        | StrOutputParser()
    )

    retrieve_docs_chain = (lambda x: x["input"]) | docsearch.as_retriever()

    chain = RunnablePassthrough.assign(context=retrieve_docs_chain).assign(
        answer=rag_chain
    )

    result = chain.invoke({"input": query})
    return result

def run_llm3(query: str, chat_history: list[dict[str, any]] = []) -> any:
    """
    Run the Language Model for Conversational Retrieval.

    This function utilizes the Langchain ChatOpenAI model and Pinecone vector store
    for Conversational Retrieval.

    Parameters:
    -----------
    query : str
        The user's query.
    chat_history : list[dict[str, any]], optional
        The chat history, defaults to an empty list.

    Returns:
    --------
    any
        The generated response.
    """
    embeddings = OpenAIEmbeddings(api_key=os.getenv("OPENAI_API_KEY"))
    docsearch = PineconeVectorStore(index_name=INDEX_NAME, embedding=embeddings)
    chat = ChatOpenAI(verbose=True, temperature=0, api_key=os.getenv("OPENAI_API_KEY"))

    qa = ConversationalRetrievalChain.from_llm(llm=chat, retriever=docsearch.as_retriever(), return_source_documents=True)
#    return qa({"question": query, "chat_history": chat_history})
    result = qa.invoke(input={"input": query})
    return result

if __name__ == "__main__":
    res=run_llm3(query="What is a Langchain chain?",c)
    print(res["answer"])
